package com.example.encrypdemo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import encrypdemo1.LoginDatabaseHelper;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextLoginUsername;
    private EditText editTextLoginPassword;
    private LoginDatabaseHelper loginDatabaseHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);  // Ensure this points to the correct layout

        // Initialize views inside onCreate
        editTextLoginUsername = findViewById(R.id.editTextLoginUsername);
        editTextLoginPassword = findViewById(R.id.editTextLoginPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);

        loginDatabaseHelper = new LoginDatabaseHelper(this);

        // Add a test user for login purposes (optional, for testing)
        loginDatabaseHelper.addUser("testuser", "password123"); // You can comment out/remove this after adding a user in DB manually

        buttonLogin.setOnClickListener(v -> {
            String username = editTextLoginUsername.getText().toString().trim();
            String password = editTextLoginPassword.getText().toString().trim();

            // Basic validation: Ensure username and password are not empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Authenticate user
                boolean isAuthenticated = loginDatabaseHelper.authenticateUser(username, password);

                if (isAuthenticated) {
                    Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                    // Navigate to the next screen (e.g., Dashboard or Home)
                    Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                    startActivity(intent);
                    finish(); // Finish the login activity to prevent going back to it
                } else {
                    Toast.makeText(LoginActivity.this, "Login Failed. Check your credentials.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

