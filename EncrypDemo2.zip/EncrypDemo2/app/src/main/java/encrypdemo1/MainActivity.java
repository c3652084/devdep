package encrypdemo1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.encrypdemo.R;

import java.security.KeyPair;

import javax.crypto.SecretKey;

public class MainActivity extends AppCompatActivity {

    private EditText editTextInput;
    private TextView textViewResult;
    private Button buttonEncryptAES, buttonDecryptAES, buttonEncryptRSA, buttonDecryptRSA;

    private SecretKey aesKey;
    private KeyPair rsaKeyPair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize AES Key and RSA Key Pair
        try {
            aesKey = KeyGeneratorHelper.generateAESKey();
            rsaKeyPair = KeyGeneratorHelper.generateRSAKeyPair();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error initializing keys", Toast.LENGTH_SHORT).show();
        }

        // Initialize UI components
        editTextInput = findViewById(R.id.editTextInput);
        textViewResult = findViewById(R.id.textViewResult);
        buttonEncryptAES = findViewById(R.id.buttonEncryptAES);
        buttonDecryptAES = findViewById(R.id.buttonDecryptAES);
        buttonEncryptRSA = findViewById(R.id.buttonEncryptRSA);
        buttonDecryptRSA = findViewById(R.id.buttonDecryptRSA);

        // Set up AES Encryption button listener
        buttonEncryptAES.setOnClickListener(v -> {
            String inputText = editTextInput.getText().toString().trim();
            if (inputText.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter some text", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                String encryptedText = AESEncryption.encrypt(inputText, aesKey);
                textViewResult.setText("Encrypted AES: " + encryptedText);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Error during AES encryption", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up AES Decryption button listener
        buttonDecryptAES.setOnClickListener(v -> {
            String inputText = editTextInput.getText().toString().trim();
            if (inputText.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter some text", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                String decryptedText = AESDecryption.decrypt(inputText, aesKey);
                textViewResult.setText("Decrypted AES: " + decryptedText);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Error during AES decryption", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up RSA Encryption button listener
        buttonEncryptRSA.setOnClickListener(v -> {
            String inputText = editTextInput.getText().toString().trim();
            if (inputText.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter some text", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                String encryptedText = RSAEncryption.encrypt(inputText, rsaKeyPair.getPublic());
                textViewResult.setText("Encrypted RSA: " + encryptedText);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Error during RSA encryption", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up RSA Decryption button listener
        buttonDecryptRSA.setOnClickListener(v -> {
            String inputText = editTextInput.getText().toString().trim();
            if (inputText.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter some text", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                String decryptedText = RSADecryption.decrypt(inputText, rsaKeyPair.getPrivate());
                textViewResult.setText("Decrypted RSA: " + decryptedText);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Error during RSA decryption", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

