package encrypdemo1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DoctorDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "doctor_management.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_DOCTORS = "doctors";
    public static final String COL_ID = "id";
    public static final String COL_NAME = "name";
    public static final String COL_SPECIALTY = "specialty";

    public DoctorDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the doctor table
        String CREATE_TABLE = "CREATE TABLE " + TABLE_DOCTORS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT, " +
                COL_SPECIALTY + " TEXT)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the existing table if it exists and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DOCTORS);
        onCreate(db);
    }

    // Insert new doctor
    public boolean addDoctor(String name, String specialty) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_SPECIALTY, specialty);
        long result = db.insert(TABLE_DOCTORS, null, values);
        db.close(); // Don't forget to close the database
        return result != -1;
    }

    // Get all doctors
    public Cursor getAllDoctors() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_DOCTORS, null);
    }

    // Update a doctor
    public boolean updateDoctor(int id, String name, String specialty) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_SPECIALTY, specialty);
        int result = db.update(TABLE_DOCTORS, values, COL_ID + " = ?", new String[]{String.valueOf(id)});
        db.close(); // Don't forget to close the database
        return result > 0;
    }

    // Delete a doctor
    public boolean deleteDoctor(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_DOCTORS, COL_ID + " = ?", new String[]{String.valueOf(id)});
        db.close(); // Don't forget to close the database
        return result > 0;
    }
}



