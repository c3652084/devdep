plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.encrypdemo"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.encrypdemo"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    // Add BCrypt dependency here
    implementation(libs.jbcrypt)
    implementation(libs.androidx.appcompat) // Add the BCrypt library

    // Add other dependencies here as necessary
}
